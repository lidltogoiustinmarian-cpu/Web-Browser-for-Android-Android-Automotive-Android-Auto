package com.example.webbrowser.shared

import android.os.Bundle
import androidx.media.MediaBrowserServiceCompat
import android.media.browse.MediaBrowser

// Acest serviciu a fost dezactivat pentru a preveni eroarea "Niciun element" în modul Browser.
// Codul este păstrat doar ca referință dar nu mai este declarat în Manifest.
class MyMusicService : MediaBrowserServiceCompat() {

    override fun onGetRoot(
        clientPackageName: String,
        clientUid: Int,
        rootHints: Bundle?
    ): MediaBrowserServiceCompat.BrowserRoot? {
        // Returnăm null pentru a refuza orice conexiune media
        return null
    }

    override fun onLoadChildren(
        parentId: String,
        result: MediaBrowserServiceCompat.Result<List<android.support.v4.media.MediaBrowserCompat.MediaItem>>
    ) {
        // Nu returnăm niciun element
        result.sendResult(null)
    }
}