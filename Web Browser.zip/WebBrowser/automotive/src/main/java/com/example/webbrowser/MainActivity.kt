package com.example.webbrowser

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.KeyEvent
import android.view.inputmethod.EditorInfo
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity
import androidx.preference.PreferenceManager
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var etUrl: EditText
    private lateinit var sharedPreferences: SharedPreferences

    override fun attachBaseContext(newBase: Context) {
        val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(newBase)
        val langCode = sharedPreferences.getString("app_language", "en") ?: "en"
        val locale = Locale(langCode)
        Locale.setDefault(locale)
        val config = newBase.resources.configuration
        config.setLocale(locale)
        super.attachBaseContext(newBase.createConfigurationContext(config))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this)

        webView = findViewById(R.id.webView)
        etUrl = findViewById(R.id.etUrl)
        val btnBack: ImageButton = findViewById(R.id.btnBack)
        val btnForward: ImageButton = findViewById(R.id.btnForward)
        val btnHome: ImageButton = findViewById(R.id.btnHome)
        val btnSettings: ImageButton = findViewById(R.id.btnSettings)

        setupWebView()

        btnBack.setOnClickListener {
            if (webView.canGoBack()) webView.goBack()
        }

        btnForward.setOnClickListener {
            if (webView.canGoForward()) webView.goForward()
        }

        btnHome.setOnClickListener {
            loadHomePage()
        }

        btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        etUrl.setOnEditorActionListener { _, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH ||
                event?.keyCode == KeyEvent.KEYCODE_ENTER
            ) {
                val input = etUrl.text.toString()
                loadUrl(input)
                true
            } else {
                false
            }
        }

        loadHomePage()
    }

    private fun setupWebView() {
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                return false
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                etUrl.setText(url)
            }
        }
    }

    private fun loadHomePage() {
        val searchEngine = sharedPreferences.getString("search_engine", "https://www.google.com/search?q=") ?: "https://www.google.com/search?q="
        val homeUrl = if (searchEngine.contains("google.com")) "https://www.google.com" else searchEngine.substringBefore("search?q=")
        webView.loadUrl(homeUrl)
    }

    private fun loadUrl(input: String) {
        val url = if (input.startsWith("http://") || input.startsWith("https://")) {
            input
        } else if (input.contains(".") && !input.contains(" ")) {
            "https://$input"
        } else {
            val searchEngine = sharedPreferences.getString("search_engine", "https://www.google.com/search?q=") ?: "https://www.google.com/search?q="
            searchEngine + input
        }
        webView.loadUrl(url)
    }

    override fun onResume() {
        super.onResume()
        val currentLang = sharedPreferences.getString("app_language", "en")
        if (Locale.getDefault().language != currentLang) {
            recreate()
        }
    }
}