package com.example.webbrowser

import androidx.car.app.CarContext
import androidx.car.app.Screen
import androidx.car.app.model.*
import androidx.preference.PreferenceManager
import java.util.Locale

class MySettingsScreen(carContext: CarContext) : Screen(carContext) {
    
    private val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(carContext)

    override fun onGetTemplate(): Template {
        val listBuilder = ItemList.Builder()

        // Motor de căutare
        val searchEngineUrl = sharedPreferences.getString("search_engine", "https://www.google.com/search?q=")
        val searchEngineNames = carContext.resources.getStringArray(R.array.search_engine_names)
        val searchEngineUrls = carContext.resources.getStringArray(R.array.search_engine_urls)
        val currentSearchEngineName = searchEngineNames.getOrNull(searchEngineUrls.indexOf(searchEngineUrl)) ?: "Google"

        listBuilder.addItem(
            Row.Builder()
                .setTitle(carContext.getString(R.string.search_engine))
                .addText(currentSearchEngineName)
                .setOnClickListener { 
                    // Cycle through search engines for simplicity in this demo
                    val nextIndex = (searchEngineUrls.indexOf(searchEngineUrl) + 1) % searchEngineUrls.size
                    sharedPreferences.edit().putString("search_engine", searchEngineUrls[nextIndex]).apply()
                    invalidate()
                }
                .build()
        )

        // Limbă
        val langCode = sharedPreferences.getString("app_language", "en") ?: "en"
        val langNames = carContext.resources.getStringArray(R.array.language_names)
        val langCodes = carContext.resources.getStringArray(R.array.language_codes)
        val currentLangName = langNames.getOrNull(langCodes.indexOf(langCode)) ?: "English"

        listBuilder.addItem(
            Row.Builder()
                .setTitle(carContext.getString(R.string.language))
                .addText(currentLangName)
                .setOnClickListener { 
                    val nextIndex = (langCodes.indexOf(langCode) + 1) % langCodes.size
                    val nextLang = langCodes[nextIndex]
                    sharedPreferences.edit().putString("app_language", nextLang).apply()
                    updateLocale(nextLang)
                    invalidate()
                }
                .build()
        )

        // Notificări
        val notificationsEnabled = sharedPreferences.getBoolean("notifications_enabled", true)
        listBuilder.addItem(
            Row.Builder()
                .setTitle(carContext.getString(R.string.notifications))
                .addText(if (notificationsEnabled) "On" else "Off")
                .setToggle(Toggle.Builder { checked ->
                    sharedPreferences.edit().putBoolean("notifications_enabled", checked).apply()
                    invalidate()
                }.setChecked(notificationsEnabled).build())
                .build()
        )

        return ListTemplate.Builder()
            .setSingleList(listBuilder.build())
            .setTitle(carContext.getString(R.string.settings))
            .setHeaderAction(Action.BACK)
            .build()
    }

    private fun updateLocale(langCode: String) {
        val locale = Locale(langCode)
        Locale.setDefault(locale)
        val config = carContext.resources.configuration
        config.setLocale(locale)
        carContext.resources.updateConfiguration(config, carContext.resources.displayMetrics)
    }
}