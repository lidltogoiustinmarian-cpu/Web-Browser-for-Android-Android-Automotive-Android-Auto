package com.example.webbrowser

import android.content.Intent
import androidx.car.app.CarAppService
import androidx.car.app.Session
import androidx.car.app.validation.HostValidator

class MyCarAppService : CarAppService() {
    override fun createHostValidator(): HostValidator {
        return HostValidator.ALLOW_ALL_HOSTS_VALIDATOR
    }

    override fun onCreateSession(): Session {
        return MyCarAppSession()
    }
}

class MyCarAppSession : Session() {
    override fun onCreateScreen(intent: Intent): androidx.car.app.Screen {
        return MyCarAppScreen(carContext)
    }
}