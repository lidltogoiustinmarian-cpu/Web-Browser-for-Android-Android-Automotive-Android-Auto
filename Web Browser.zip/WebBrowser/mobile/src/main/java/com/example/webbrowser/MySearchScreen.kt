package com.example.webbrowser

import androidx.car.app.CarContext
import androidx.car.app.Screen
import androidx.car.app.model.*

class MySearchScreen(
    carContext: CarContext,
    private val onSearch: (String) -> Unit
) : Screen(carContext) {

    override fun onGetTemplate(): Template {
        return SearchTemplate.Builder(object : SearchTemplate.SearchCallback {
            override fun onSearchTextChanged(searchText: String) {
                // Opțional: Sugestii în timp ce scrii
            }

            override fun onSearchSubmitted(searchText: String) {
                onSearch(searchText)
                screenManager.pop()
            }
        })
            .setHeaderAction(Action.BACK)
            .setShowKeyboardByDefault(true)
            .setInitialSearchText("Cauta sau URL...")
            .build()
    }
}