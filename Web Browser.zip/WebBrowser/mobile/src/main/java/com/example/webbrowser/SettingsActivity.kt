package com.example.webbrowser

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.preference.ListPreference
import androidx.preference.PreferenceFragmentCompat
import java.util.Locale

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        if (savedInstanceState == null) {
            supportFragmentManager
                .beginTransaction()
                .replace(R.id.settings, SettingsFragment())
                .commit()
        }
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }

    class SettingsFragment : PreferenceFragmentCompat() {
        override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
            setPreferencesFromResource(R.xml.preferences, rootKey)

            val langPreference = findPreference<ListPreference>("app_language")
            if (langPreference != null) {
                val locales = Locale.getAvailableLocales()
                val entries = locales.map { it.displayName }.toTypedArray()
                val entryValues = locales.map { it.language }.toTypedArray()
                
                // Sort them to be user friendly
                val sorted = entries.zip(entryValues).sortedBy { it.first }
                langPreference.entries = sorted.map { it.first }.toTypedArray()
                langPreference.entryValues = sorted.map { it.second }.toTypedArray()
            }
        }
    }
}