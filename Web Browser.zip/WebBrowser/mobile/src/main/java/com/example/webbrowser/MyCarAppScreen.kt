package com.example.webbrowser

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Handler
import android.os.Looper
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.car.app.AppManager
import androidx.car.app.CarContext
import androidx.car.app.Screen
import androidx.car.app.SurfaceCallback
import androidx.car.app.SurfaceContainer
import androidx.car.app.model.*
import androidx.car.app.navigation.model.NavigationTemplate
import androidx.preference.PreferenceManager
import java.util.Locale

class MyCarAppScreen(carContext: CarContext) : Screen(carContext) {

    private var webView: WebView? = null
    private var surfaceContainer: SurfaceContainer? = null
    private val handler = Handler(Looper.getMainLooper())
    private var reuseBitmap: Bitmap? = null
    private var reuseCanvas: Canvas? = null
    
    // Dimensiuni virtuale pentru WebView
    private val webWidth = 1280
    private val webHeight = 720

    private val refreshTask = object : Runnable {
        override fun run() {
            renderWebViewToSurface()
            handler.postDelayed(this, 66) // ~15 FPS pentru fluiditate mai bună
        }
    }

    init {
        applyLocale()
        handler.post {
            webView = WebView(carContext).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.useWideViewPort = true
                settings.loadWithOverviewMode = true
                settings.userAgentString = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
                
                webViewClient = WebViewClient()
                
                // Forțăm dimensiunile pentru off-screen rendering
                layout(0, 0, webWidth, webHeight)
                measure(
                    View.MeasureSpec.makeMeasureSpec(webWidth, View.MeasureSpec.EXACTLY),
                    View.MeasureSpec.makeMeasureSpec(webHeight, View.MeasureSpec.EXACTLY)
                )
                
                val sharedPrefs = PreferenceManager.getDefaultSharedPreferences(carContext)
                val searchEngine = sharedPrefs.getString("search_engine", "https://www.google.com/search?q=") ?: "https://www.google.com/search?q="
                val homeUrl = if (searchEngine.contains("google.com")) "https://www.google.com" else searchEngine.substringBefore("search?q=")
                loadUrl(homeUrl)
            }
        }

        carContext.getCarService(AppManager::class.java)
            .setSurfaceCallback(object : SurfaceCallback {
                override fun onSurfaceAvailable(container: SurfaceContainer) {
                    surfaceContainer = container
                    handler.post(refreshTask)
                }

                override fun onSurfaceDestroyed(container: SurfaceContainer) {
                    surfaceContainer = null
                    handler.removeCallbacks(refreshTask)
                }
            })
    }

    private fun applyLocale() {
        val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(carContext)
        val langCode = sharedPreferences.getString("app_language", "en") ?: "en"
        val locale = Locale(langCode)
        Locale.setDefault(locale)
        val config = carContext.resources.configuration
        config.setLocale(locale)
        carContext.resources.updateConfiguration(config, carContext.resources.displayMetrics)
    }

    private fun renderWebViewToSurface() {
        val container = surfaceContainer ?: return
        val view = webView ?: return
        val surface = container.surface ?: return
        if (!surface.isValid) return

        try {
            if (reuseBitmap == null || reuseBitmap?.width != webWidth || reuseBitmap?.height != webHeight) {
                reuseBitmap = Bitmap.createBitmap(webWidth, webHeight, Bitmap.Config.ARGB_8888)
                reuseCanvas = Canvas(reuseBitmap!!)
            }

            // Desenăm WebView-ul în bitmap-ul de cache
            reuseCanvas?.drawColor(Color.WHITE) // Fundal alb înainte de randare
            view.draw(reuseCanvas!!)

            // Încercăm să obținem un canvas de la suprafața mașinii
            val canvas = try {
                surface.lockHardwareCanvas()
            } catch (e: Exception) {
                surface.lockCanvas(null)
            }

            if (canvas != null) {
                val scaleX = canvas.width.toFloat() / webWidth
                val scaleY = canvas.height.toFloat() / webHeight
                val scale = Math.min(scaleX, scaleY) // Păstrăm aspect ratio dacă e necesar, sau scaleX/scaleY pt full screen
                
                canvas.save()
                canvas.scale(scaleX, scaleY)
                canvas.drawBitmap(reuseBitmap!!, 0f, 0f, null)
                canvas.restore()
                
                surface.unlockCanvasAndPost(canvas)
            }
        } catch (e: Exception) {
            // Ignorăm erorile de sincronizare a suprafeței
        }
    }

    private fun handleSearch(query: String) {
        handler.post {
            val url = if (query.startsWith("http://") || query.startsWith("https://")) {
                query
            } else if (query.contains(".") && !query.contains(" ")) {
                "https://$query"
            } else {
                val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(carContext)
                val searchEngine = sharedPreferences.getString("search_engine", "https://www.google.com/search?q=") ?: "https://www.google.com/search?q="
                searchEngine + query
            }
            webView?.loadUrl(url)
        }
    }

    override fun onGetTemplate(): Template {
        // Folosim un NavigationTemplate care are un ActionStrip pentru a nu fi considerat "gol"
        return NavigationTemplate.Builder()
            .setActionStrip(
                ActionStrip.Builder()
                    .addAction(Action.Builder()
                        .setTitle(carContext.getString(R.string.search_url))
                        .setOnClickListener { 
                            screenManager.push(MySearchScreen(carContext) { query ->
                                handleSearch(query)
                            })
                        }
                        .build())
                    .addAction(Action.Builder()
                        .setTitle("<")
                        .setOnClickListener { 
                            handler.post { if (webView?.canGoBack() == true) webView?.goBack() }
                        }
                        .build())
                    .addAction(Action.Builder()
                        .setTitle(">")
                        .setOnClickListener { 
                            handler.post { if (webView?.canGoForward() == true) webView?.goForward() }
                        }
                        .build())
                    .addAction(Action.Builder()
                        .setTitle(carContext.getString(R.string.settings))
                        .setOnClickListener { 
                            screenManager.push(MySettingsScreen(carContext))
                        }
                        .build())
                    .build()
            )
            .build()
    }
}